package com.coupons.models;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
